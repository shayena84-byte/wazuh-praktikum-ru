#!/usr/bin/env bash
set -Eeuo pipefail

# One-time setup for a limited, read-only Ubuntu diagnostic runner.
# Run as your normal Ubuntu user with sudo rights, NOT as root.

REPO_OWNER="shayena84-byte"
REPO_NAME="ubuntu-server-management"
FULL_REPO="${REPO_OWNER}/${REPO_NAME}"
RUNNER_USER="github-runner-diag"
RUNNER_DIR="/opt/github-runner-diag"
WORK_DIR=""
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

say() { printf '\n==> %s\n' "$*"; }
fail() { echo "ERROR: $*" >&2; exit 1; }
cleanup() { if [ -n "$WORK_DIR" ] && [ -d "$WORK_DIR" ]; then rm -rf -- "$WORK_DIR"; fi; }
trap cleanup EXIT

[ "$EUID" -ne 0 ] || fail "Run this script as your normal Ubuntu account, not root."
[ -f /etc/os-release ] || fail "OS details not found."
# shellcheck disable=SC1091
. /etc/os-release
[ "${ID:-}" = "ubuntu" ] || fail "Expected Ubuntu Server."
[ -f "$SCRIPT_DIR/repository/.github/workflows/ubuntu-audit.yml" ] || fail "Missing repository files: extract the full kit first."

case "$(uname -m)" in
  x86_64) ARCH=x64 ;;
  aarch64) ARCH=arm64 ;;
  *) fail "Unsupported CPU architecture: $(uname -m)" ;;
esac

say "Check administrator privilege and install prerequisites"
sudo -v
sudo apt-get update
sudo apt-get install -y ca-certificates curl git gh python3 tar

AUTH_CREATED=0
if ! gh auth status -h github.com >/dev/null 2>&1; then
  AUTH_CREATED=1
  say "Authorize GitHub CLI. Use the displayed one-time code in the browser on your PC."
  gh auth login --hostname github.com --git-protocol https --scopes repo,workflow --web
fi
gh auth setup-git
LOGIN="$(gh api user --jq .login)"
[ "$LOGIN" = "$REPO_OWNER" ] || fail "Signed in as '$LOGIN', but expected '$REPO_OWNER'. Switch GitHub accounts before retrying."

say "Create isolated private repository: $FULL_REPO"
if gh repo view "$FULL_REPO" >/dev/null 2>&1; then
  VISIBILITY="$(gh repo view "$FULL_REPO" --json visibility --jq .visibility)"
  [ "$VISIBILITY" = PRIVATE ] || fail "The repository already exists but is not private. Refusing to continue."
  gh api "repos/$FULL_REPO/contents/.github/workflows/ubuntu-audit.yml" >/dev/null 2>&1 || fail "Existing repository has no matching workflow. Not modifying existing files."
  echo "Private repository already exists with a workflow: skipping creation."
else
  WORK_DIR="$(mktemp -d)"
  cp -a "$SCRIPT_DIR/repository/." "$WORK_DIR/"
  git -C "$WORK_DIR" init -b main
  git -C "$WORK_DIR" add .
  git -C "$WORK_DIR" -c user.name="Ubuntu Diagnostics Setup" -c user.email="setup@users.noreply.github.com" commit -m "Add safe read-only Ubuntu diagnostics"
  gh repo create "$FULL_REPO" --private --description "Read-only Ubuntu Server diagnostics on XCP-ng" --source "$WORK_DIR" --remote origin --push
  VISIBILITY="$(gh repo view "$FULL_REPO" --json visibility --jq .visibility)"
  [ "$VISIBILITY" = PRIVATE ] || fail "Repository visibility check failed: $VISIBILITY"
fi

say "Create a dedicated unprivileged runner account"
if id "$RUNNER_USER" >/dev/null 2>&1; then
  [ -d "$RUNNER_DIR" ] || fail "Runner user exists but $RUNNER_DIR does not."
  [ ! -f "$RUNNER_DIR/.runner" ] || fail "Runner already registered; not overwriting."
else
  sudo adduser --system --group --home "$RUNNER_DIR" --shell /bin/bash "$RUNNER_USER"
fi
if id -nG "$RUNNER_USER" | tr ' ' '\n' | grep -qx sudo; then
  fail "Runner account unexpectedly belongs to sudo group."
fi

say "Resolve latest official Actions runner package and verify its SHA256"
mapfile -t META < <(python3 - "$ARCH" <<'PY'
import json
import re
import sys
import urllib.request

arch = sys.argv[1]
url = 'https://api.github.com/repos/actions/runner/releases/latest'
req = urllib.request.Request(url, headers={'User-Agent': 'ubuntu-diagnostics-setup', 'Accept': 'application/vnd.github+json'})
with urllib.request.urlopen(req, timeout=30) as response:
    release = json.load(response)
pattern = re.compile(r'^actions-runner-linux-' + re.escape(arch) + r'-[\d.]+\.tar\.gz$')
assets = [a for a in release['assets'] if pattern.match(a['name'])]
if len(assets) != 1:
    raise RuntimeError('Cannot identify unique runner package for architecture ' + arch)
asset = assets[0]
sha = asset.get('digest') or ''
if sha.startswith('sha256:'):
    sha = sha.split(':', 1)[1]
else:
    match = re.search(re.escape(asset['name']) + r'\s+([a-fA-F0-9]{64})', release.get('body') or '')
    sha = match.group(1) if match else ''
if not re.fullmatch(r'[0-9a-fA-F]{64}', sha):
    raise RuntimeError('Missing package checksum in official release; refusing unverified download')
package_url = asset['browser_download_url']
if not package_url.startswith('https://github.com/actions/runner/releases/download/'):
    raise RuntimeError('Unexpected download URL host')
print(package_url)
print(sha)
PY
)
[ "${#META[@]}" -eq 2 ] || fail "Could not resolve official runner download metadata."
PACKAGE_URL="${META[0]}"
PACKAGE_SHA="${META[1]}"
ARCHIVE="$(mktemp -t runner.XXXXXXXX.tar.gz)"
trap 'rm -f "${ARCHIVE:-}"; cleanup' EXIT
curl --fail --location --show-error --silent --retry 3 "$PACKAGE_URL" --output "$ARCHIVE"
printf '%s  %s\n' "$PACKAGE_SHA" "$ARCHIVE" | sha256sum --check --status || fail "Runner SHA256 checksum mismatch."
sudo tar -xzf "$ARCHIVE" -C "$RUNNER_DIR"
sudo chown -R "$RUNNER_USER:$RUNNER_USER" "$RUNNER_DIR"

say "Request short-lived registration token and register the runner"
REG_TOKEN="$(gh api -X POST "repos/$FULL_REPO/actions/runners/registration-token" --jq .token)"
[ -n "$REG_TOKEN" ] || fail "Runner registration token unavailable."
RUNNER_NAME="$(hostname -s)-diagnostics"
sudo -u "$RUNNER_USER" bash -c 'cd "$1"; shift; exec ./config.sh "$@"' _ "$RUNNER_DIR" \
  --url "https://github.com/$FULL_REPO" \
  --token "$REG_TOKEN" \
  --name "$RUNNER_NAME" \
  --labels ubuntu-diagnostics \
  --work _work \
  --unattended
unset REG_TOKEN

say "Install and start the systemd runner service"
( cd "$RUNNER_DIR" && sudo ./svc.sh install "$RUNNER_USER" && sudo ./svc.sh start && sudo ./svc.sh status ) || fail "Runner service installation/start failed"

if [ "$AUTH_CREATED" -eq 1 ]; then
  say "Remove the temporary GitHub CLI authentication from this server"
  gh auth logout --hostname github.com --user "$REPO_OWNER" || echo "NOTE: run gh auth logout manually if you no longer need that credential"
fi

cat <<INFO

SETUP COMPLETE
Private repository: https://github.com/$FULL_REPO
Runner: $RUNNER_NAME (user: $RUNNER_USER)

Request diagnostics by opening an Issue whose title starts with:
  [audit] Check Ubuntu Server

Do not put passwords, secrets, or arbitrary commands into Issues.
The audit is read-only and posts its result as a comment on that Issue.
INFO
