# Ubuntu Server management — safe diagnostics

Private repository for a single Ubuntu Server VM on XCP-ng.

## How the integration works

1. An authorized owner creates a GitHub Issue with a title starting with `[audit]`.
2. A dedicated self-hosted GitHub Actions runner on Ubuntu executes a **fixed, read-only** audit workflow.
3. The runner posts diagnostics as a comment on that private Issue.
4. ChatGPT, using the connected GitHub app, can create audit Issues and read the results in subsequent turns.

There is **no arbitrary remote shell** in this setup, and the runner user has no `sudo` permission. That is intentional. The runner can still read world-readable system data and is a privileged boundary: anyone able to modify workflows on the default branch could potentially execute code as the runner user.

Do not change repository visibility to public. Do not use pull-request workflows on this runner. Do not grant the runner user sudo access. Disable the runner in repository Settings > Actions > Runners when it is not needed.

## Start a diagnostic run

Open Issues > New issue, title it:

`[audit] Check Ubuntu Server`

Or ask ChatGPT to create an Issue in this repository. The report will be posted as an Issue comment when the runner completes.

## Security and limitations

- Network connection is **outbound HTTPS from Ubuntu to GitHub**, no inbound SSH access required.
- Diagnostics can include local IP addresses, domain names, and service information; GitHub administrators and parties with repository access can see them.
- The workflow is fixed. Issue contents are never passed into a shell command.
- The username `github-runner-diag` should not belong to `sudo` or administrative groups.
- This does not enable ChatGPT itself to log into the server or run any command. It provides a narrow remote diagnostics interface through the GitHub connector.

Consult the [official GitHub guidance](https://docs.github.com/en/actions/how-tos/manage-runners/self-hosted-runners/add-runners) for runner maintenance.
